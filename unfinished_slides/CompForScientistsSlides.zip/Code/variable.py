#this creates the variable called x and sets or assigns 10 as its value
x = 10
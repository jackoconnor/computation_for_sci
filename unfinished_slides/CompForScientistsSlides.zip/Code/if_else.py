#set the values of a and b
a = 10
b = 45

#check if a equals b
if(a == b):
    print('a is equal to b')
    
#if they aren't equal do this
else: 
    print('a is not equal to b')
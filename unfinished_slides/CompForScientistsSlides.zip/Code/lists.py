chemists = ['Curie', 'Avogadro', 'Boyle']

numbers = [2, -32, 17, 0]

list1 = [5, 'work', 8,  9]

list2 = [6, 'something', ['a', 'b', 'c']]
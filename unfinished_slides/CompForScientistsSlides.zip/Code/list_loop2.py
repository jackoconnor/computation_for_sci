numbers = [1, 3, 5, 8 , 11]
length = len(numbers)

for i in range(length):
    print(numbers[i])
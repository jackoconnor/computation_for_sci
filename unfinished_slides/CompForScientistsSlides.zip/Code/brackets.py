#now what will the value of this expression be? 
(x+x)*y
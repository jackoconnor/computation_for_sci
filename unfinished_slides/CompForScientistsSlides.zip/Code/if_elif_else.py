#set the values of a and b
a = 45
b = 10

#check if a is greater than b
if a > b:
    print('a is greater than b')

#if a isn't greater than b, check if a is equal to b
elif b == a:
    print('a is equal to b')

#if a isn't greater than b and they aren't equal, a must be less than b
else:
    print('a is less than b')
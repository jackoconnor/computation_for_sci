def first_pos(a):
    for i in range(len(a)):
        if a[i] > 0:
            return -1
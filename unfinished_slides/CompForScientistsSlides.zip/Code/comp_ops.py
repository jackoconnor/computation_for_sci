x = 3
y = 5

#what do you think the value of this expression will be? 
x+x*y
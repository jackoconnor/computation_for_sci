#set the values of a and b
a = 45
b = 10

#check if a is greater than b
if(a > b):
    print('a is greater than b')
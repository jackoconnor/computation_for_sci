s = 0               #this variable will store the sum
i = 1               #the first number in the sum

while (i <= 10):
    s += i          #add the next number to our total
    i += 1          #move on to the next number
    
print(s)            #print the result
def quadruple(x):
    return 4 * x
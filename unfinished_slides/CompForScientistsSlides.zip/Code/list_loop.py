numbers = [1, 3, 5, 8, 11]

for i in numbers:
    print(i)
def greeting(name):
    greet = 'Hello ' + name + '! How are you?'
    return greet
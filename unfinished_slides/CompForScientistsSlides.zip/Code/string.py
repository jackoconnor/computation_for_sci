cool_place = "Antarctica"

sen = 'single and double quotes both work'
#addition
x+y

#subtraction
x-y

#multiplication
x*y

#division
x/y
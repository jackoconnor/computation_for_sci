s = 0               #this varaible will store the sum
i = 10              #the first number in the sum

while(i >= 1):
    s += i          #add the next number to our total
    i -= 1          #move on to the next number
    
print(s)
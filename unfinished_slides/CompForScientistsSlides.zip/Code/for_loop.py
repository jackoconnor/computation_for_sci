s = 0               #this variable will store the sum
for i in range(10):
    s += i          #add the next number to our total
print(s)            #print the result
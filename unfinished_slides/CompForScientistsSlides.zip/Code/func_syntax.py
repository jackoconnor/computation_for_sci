def function_name(parameters):
    #function body here
    return value